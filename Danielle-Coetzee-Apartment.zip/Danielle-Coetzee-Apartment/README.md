# Build an Apartment Starter Project

This project is part of [Udacity](https://www.udacity.com "Udacity - Be in demand")'s [VR Developer Nanodegree](https://www.udacity.com/course/vr-developer-nanodegree--nd017).

## Versions
- Unity 2017.2.0f3
- GVR Unity SDK v1.70.0

# Project Information

The Project took me roughly 12 hours to complete, in terms of building all the models in blender and getting the lighting just right. The annimation was quick and only took about 5 minuets in total I would say.

The one thing I really enjoyed about this prject was the freedom to build exactly what I wanted to build and that I wasn't forced to use your models.

With this project I wouldnt say I found anything too challenging, I did how ever require some time to understand how each light effects the scene differently.


# Plagerism declaration
- All the models in the room are mine and where made from scratch by me.
- (except of course the appartment shell which was provided by udacity).
- The art work you see in the living room and on the fridge was not done by be but was sourced online at the following locations:
    -pinimg.com
    -wikimedia.org
-I also recieved a lot of my design inspiration from pintrest.